<div class="contain">
    <div class="box b1">
      <div class="col li1">
          <h1>Promotion</h1>
          <h3>Gérer les promotions de l'école</h3>
      </div>
      <div class="col li2"><button>+ Ajouter une promotion</button></div>
    </div>
    <div class="box b2">
<<<<<<< HEAD
        <div class="rec"></div>
        <div class="rec"></div>
        <div class="rec"></div>
        <div class="rec"></div>
=======
        <div class="rec rec1">
            <p class="number">0</p>
        </div>
        <div class="rec rec2"></div>
        <div class="rec rec3"></div>
        <div class="rec rec4"></div>
>>>>>>> b89b887b3f92b24d80b73a84ca27ebb08e03a3e7

    </div>
    <div class="box b3">
        <div class="ligne l1">
            <div class="range r1">
            <input type="text" name="recherche" id="recherche" placeholder="    Rechercher..." class="recherche">
           </div>
            <div class="range"></div>
            <div class="range"></div>
            <div class="range"></div>
        </div>
        <div class="ligne l2"></div>

    </div>
</div>



<<<<<<< HEAD
<!-- <button>+ Ajouter une promotion</button>
        <div class="texte"><h1>Promotion</h1>
        <h3>Gérer les promotions de l'école</h3>
        </div> -->
=======
>>>>>>> b89b887b3f92b24d80b73a84ca27ebb08e03a3e7
