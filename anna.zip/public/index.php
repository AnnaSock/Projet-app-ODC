<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


<<<<<<< HEAD


require_once __DIR__ . '/../app/routes/route.web.php';
=======
require_once __DIR__ ."/../app/enums/chemins.php";
require_once __DIR__ .chemins::ROUTE -> value;
>>>>>>> b89b887b3f92b24d80b73a84ca27ebb08e03a3e7

